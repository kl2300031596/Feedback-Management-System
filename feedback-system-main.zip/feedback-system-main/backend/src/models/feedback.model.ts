class Feedback {
    constructor(public name: string, public feedback: string) {}
  }
  
  export default Feedback;
  